			<div class="lang-box">
				@if(app()->isLocale('ru'))
					<a class="lang" href="/lang/uz">UZ</a>
				@else
					<a class="lang" href="/lang/ru">RU</a>
				@endif
			</div>